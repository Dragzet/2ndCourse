package task2;

public interface Mathematicae {

    int add(int a, int b);
    int negative(int a);

}
