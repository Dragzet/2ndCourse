package ClassesImplement;

public interface Movable{
    void move();
}
