package ClassesImplement;

public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog(5, 22);
        Sheep sheep = new Sheep(7, 45);

        System.out.printf("ClassesImplement.Dog's age is %s\n", dog.toHumanAge());
        System.out.printf("ClassesImplement.Sheep's age is %s\n", sheep.toHumanAge());

        dog.move();
        sheep.move();

    }
}