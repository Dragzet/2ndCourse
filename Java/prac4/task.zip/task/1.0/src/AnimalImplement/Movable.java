package AnimalImplement;

public interface Movable{
    void move();
}
